import { Component, OnInit } from '@angular/core';
import { Products } from '../products';

@Component({
  selector: 'app-serach-form',
  templateUrl: './serach-form.component.html',
  styleUrls: ['./serach-form.component.css']
})
export class SerachFormComponent implements OnInit {
products:Products[];
  constructor() { }

  ngOnInit() {
  }

  product:Products;
  displayProducts(displayform)
  {
    for(let i=0;i<this.products.length;i++)
    {
      if(this.products[i].id==displayform.value.id)
      {
        this.product=this.products[i];
      }
      
    }
  }

}
