import { Component, OnInit } from '@angular/core';
import { ProductListService } from '../product-list.service';
import { Product } from '../product';
@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  constructor(private service: ProductListService ) { }
  proList: Product[];

  ngOnInit() {

  }

}
