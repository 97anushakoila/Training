package com.capg.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.capg.pom.RegisterPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegisterStepsDefinition {
	
	WebDriver driver;
	
	@Given("^user is on 'registration' page$")
	public void user_is_on_registration_page() throws Throwable {
		driver = RegisterPOM.getWebDriver();
		String url = "file:///C:/Users/adachand/Desktop/VV%20AT%20M4_MPT%20Sample%20Que/registration.html";
		driver.get(url);
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
	   WebElement fullName = RegisterPOM.getFullName();
	   fullName.sendKeys("");
	   WebElement button = RegisterPOM.getButton();
	   button.click();
	}

	@Then("^displays 'Please fill the full Name'$")
	public void displays_Please_fill_the_full_Name() throws Throwable {
		 String expectedMessage="Please fill the Full Name";
	        String actualMessage=driver.switchTo().alert().getText();
	        Assert.assertEquals(expectedMessage, actualMessage);
	        Thread.sleep(1000);
	        driver.switchTo().alert().accept();
	        driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya.com");
		   WebElement button = RegisterPOM.getButton();
		   button.click();
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		 String expectedMessage="Please enter valid Email Id.";
	        String actualMessage=driver.switchTo().alert().getText();
	        Assert.assertEquals(expectedMessage, actualMessage);
	        Thread.sleep(1000);
	        driver.switchTo().alert().accept();
	        driver.close();
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("");
		   WebElement button = RegisterPOM.getButton();
		   button.click();
	}

	@Then("^display 'Please fill Mobile No\\.'$")
	public void display_Please_fill_Mobile_No() throws Throwable {
		 String expectedMessage="Please fill the Mobile No.";
	        String actualMessage=driver.switchTo().alert().getText();
	        Assert.assertEquals(expectedMessage, actualMessage);
	        Thread.sleep(1000);
	        driver.switchTo().alert().accept();
	        driver.close();
	}

	@When("^user enters wrong mobile number$")
	public void user_enters_wrong_mobile_number() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("78945");
		   WebElement button = RegisterPOM.getButton();
		   button.click();
	}

	@Then("^display 'Please enter valid Mobile Number'$")
	public void display_Please_enter_valid_Mobile_Number() throws Throwable {
		 String expectedMessage="Please enter valid Contact no.";
	        String actualMessage=driver.switchTo().alert().getText();
	        Assert.assertEquals(expectedMessage, actualMessage);
	        Thread.sleep(1000);
	        driver.switchTo().alert().accept();
	        driver.close();
	}

	@When("^user does not select any of the checkboxes$")
	public void user_does_not_select_any_of_the_checkboxes() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("9010634343");
		   WebElement gender = RegisterPOM.getGender();
		   gender.click();
		   WebElement button = RegisterPOM.getButton();
		   button.click();
	}

	@Then("^display 'Please select gender'$")
	public void display_Please_select_gender() throws Throwable {
		
	}

	@When("^user does not select any of the city options$")
	public void user_does_not_select_any_of_the_city_options() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("9010634343");
		   WebElement gender = RegisterPOM.getGender();
		   gender.click();
		   WebElement city = RegisterPOM.getCity();
		   Select select=new Select(city);
		   select.selectByIndex(0);
		   WebElement button = RegisterPOM.getButton();
		   button.click();		   
	}

	@Then("^display 'Please fill City'$")
	public void display_Please_fill_City() throws Throwable {
		String expectedMessage="Please select city";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(1000);
        driver.switchTo().alert().accept();
        driver.close();
	}

	@When("^user does not select any of the state options$")
	public void user_does_not_select_any_of_the_state_options() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("9010634343");
		   WebElement gender = RegisterPOM.getGender();
		   gender.click();
		   WebElement city = RegisterPOM.getCity();
		   Select select1=new Select(city);
		   select1.selectByIndex(2);
		   WebElement state = RegisterPOM.getState();
		   Select select2=new Select(state);
		   select2.selectByIndex(0);
		   WebElement button = RegisterPOM.getButton();
		   button.click();
	}
	
	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
		String expectedMessage="Please select state";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(1000);
        driver.switchTo().alert().accept();
        driver.close();
	}

	@When("^user enters invalid subject category$")
	public void user_enters_invalid_subject_category() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("9010634343");
		   WebElement gender = RegisterPOM.getGender();
		   gender.click();
		   WebElement city = RegisterPOM.getCity();
		   Select select1=new Select(city);
		   select1.selectByIndex(2);
		   WebElement state = RegisterPOM.getState();
		   Select select2=new Select(state);
		   select2.selectByIndex(2);
		   WebElement subjectCategory = RegisterPOM.getSubjectCategory();
		   subjectCategory.sendKeys("");
		   WebElement button = RegisterPOM.getButton();
		   button.click();
	}

	@Then("^displays 'Please fill the subject category'$")
	public void displays_Please_fill_the_subject_category() throws Throwable {
		String expectedMessage="Please fill the Subject Category";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(1000);
        driver.switchTo().alert().accept();
        driver.close();
	}

	@When("^user enters invalid paper name$")
	public void user_enters_invalid_paper_name() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("9010634343");
		   WebElement gender = RegisterPOM.getGender();
		   gender.click();
		   WebElement city = RegisterPOM.getCity();
		   Select select1=new Select(city);
		   select1.selectByIndex(2);
		   WebElement state = RegisterPOM.getState();
		   Select select2=new Select(state);
		   select2.selectByIndex(2);
		   WebElement subjectCategory = RegisterPOM.getSubjectCategory();
		   subjectCategory.sendKeys("Artificial Intelligence");
		   WebElement paperName = RegisterPOM.getPaperName();
		   paperName.sendKeys("");
		   WebElement button = RegisterPOM.getButton();
		   button.click();
	}

	@Then("^displays 'Please fill paper name'$")
	public void displays_Please_fill_paper_name() throws Throwable {
		String expectedMessage="Please fill the Paper Name";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(1000);
        driver.switchTo().alert().accept();
        driver.close();
	}

	@When("^user enters invalid number of authors$")
	public void user_enters_invalid_number_of_authors() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("9010634343");
		   WebElement gender = RegisterPOM.getGender();
		   gender.click();
		   WebElement city = RegisterPOM.getCity();
		   Select select1=new Select(city);
		   select1.selectByIndex(2);
		   WebElement state = RegisterPOM.getState();
		   Select select2=new Select(state);
		   select2.selectByIndex(2);
		   WebElement subjectCategory = RegisterPOM.getSubjectCategory();
		   subjectCategory.sendKeys("Artificial Intelligence");
		   WebElement paperName = RegisterPOM.getPaperName();
		   paperName.sendKeys("Internal");
		   WebElement authors = RegisterPOM.getAuthors();
		   authors.sendKeys("");
		   WebElement button = RegisterPOM.getButton();
		   button.click();
	}

	@Then("^displays 'Please fill number of authors'$")
	public void displays_Please_fill_number_of_authors() throws Throwable {
		String expectedMessage="Pls. fill the authors";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(1000);
        driver.switchTo().alert().accept();
        driver.close();
	}

	@When("^user enters invalid company name$")
	public void user_enters_invalid_company_name() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("9010634343");
		   WebElement gender = RegisterPOM.getGender();
		   gender.click();
		   WebElement city = RegisterPOM.getCity();
		   Select select1=new Select(city);
		   select1.selectByIndex(2);
		   WebElement state = RegisterPOM.getState();
		   Select select2=new Select(state);
		   select2.selectByIndex(2);
		   WebElement subjectCategory = RegisterPOM.getSubjectCategory();
		   subjectCategory.sendKeys("Artificial Intelligence");
		   WebElement paperName = RegisterPOM.getPaperName();
		   paperName.sendKeys("Internal");
		   WebElement authors = RegisterPOM.getAuthors();
		   authors.sendKeys("2");
		   WebElement companyName = RegisterPOM.getCompanyName();
		   companyName.sendKeys("");
		   WebElement button = RegisterPOM.getButton();
		   button.click();

	}

	@Then("^displays 'Please fill company name'$")
	public void displays_Please_fill_company_name() throws Throwable {
		String expectedMessage="Please fill Company Name";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(1000);
        driver.switchTo().alert().accept();
        driver.close();
	}

	@When("^user enters invalid designation$")
	public void user_enters_invalid_designation() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("9010634343");
		   WebElement gender = RegisterPOM.getGender();
		   gender.click();
		   WebElement city = RegisterPOM.getCity();
		   Select select1=new Select(city);
		   select1.selectByIndex(2);
		   WebElement state = RegisterPOM.getState();
		   Select select2=new Select(state);
		   select2.selectByIndex(2);
		   WebElement subjectCategory = RegisterPOM.getSubjectCategory();
		   subjectCategory.sendKeys("Artificial Intelligence");
		   WebElement paperName = RegisterPOM.getPaperName();
		   paperName.sendKeys("Internal");
		   WebElement authors = RegisterPOM.getAuthors();
		   authors.sendKeys("2");
		   WebElement companyName = RegisterPOM.getCompanyName();
		   companyName.sendKeys("Capgemini");
		   WebElement designation = RegisterPOM.getDesignation();
		   designation.sendKeys("");
		   WebElement button = RegisterPOM.getButton();
		   button.click();
	}

	@Then("^displays 'Please fill designation'$")
	public void displays_Please_fill_designation() throws Throwable {
		String expectedMessage="Please fill Designation";
        String actualMessage=driver.switchTo().alert().getText();
        Assert.assertEquals(expectedMessage, actualMessage);
        Thread.sleep(1000);
        driver.switchTo().alert().accept();
        driver.close();
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		   WebElement fullName = RegisterPOM.getFullName();
		   fullName.sendKeys("Lavanya Adapa");
		   WebElement email = RegisterPOM.getEmail();
		   email.sendKeys("lavanya@gmail.com");
		   WebElement mobileno = RegisterPOM.getMobileNo();
		   mobileno.sendKeys("9010634343");
		   WebElement gender = RegisterPOM.getGender();
		   gender.click();
		   WebElement city = RegisterPOM.getCity();
		   Select select1=new Select(city);
		   select1.selectByIndex(2);
		   WebElement state = RegisterPOM.getState();
		   Select select2=new Select(state);
		   select2.selectByIndex(2);
		   WebElement subjectCategory = RegisterPOM.getSubjectCategory();
		   subjectCategory.sendKeys("Artificial Intelligence");
		   WebElement paperName = RegisterPOM.getPaperName();
		   paperName.sendKeys("Internal");
		   WebElement authors = RegisterPOM.getAuthors();
		   authors.sendKeys("2");
		   WebElement companyName = RegisterPOM.getCompanyName();
		   companyName.sendKeys("Capgemini");
		   WebElement designation = RegisterPOM.getDesignation();
		   designation.sendKeys("Analyst");
		   
	}

	@Then("^displays 'Registration Completed!!!'$")
	public void displays_Registration_Completed() throws Throwable {
		WebElement button = RegisterPOM.getButton();
		   button.click();
	}


	
}
