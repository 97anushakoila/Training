package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.LoginPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepsDefinition {

	WebDriver driver;

	@Given("^Open any browser and enter url for login$")
	public void open_any_browser_and_enter_url_for_login() throws Throwable {

		driver = LoginPOM.getWebDriver();
		String url = "file:///C:/Users/adachand/Desktop/VV%20AT%20M4_MPT%20Sample%20Que/login.html";
		driver.get(url);
	}

	@When("^User enters valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enters_valid_username_and_valid_password(String username, String password) throws Throwable {
		WebElement userField = LoginPOM.getUserField();
		userField.sendKeys(username);

		WebElement passwordField = LoginPOM.getPasswordField();
		passwordField.sendKeys(password);
	}

	@Then("^Login successful and registeration page gets displayed$")
	public void login_successful_and_registeration_page_gets_displayed() throws Throwable {
		WebElement loginButton = LoginPOM.getLoginButton();
		loginButton.click();
	}

	@When("^User enters invalid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enters_invalid_username_and_valid_password(String username, String password) throws Throwable {
		WebElement userField = LoginPOM.getUserField();
		userField.sendKeys(username);

		WebElement passwordField = LoginPOM.getPasswordField();
		passwordField.sendKeys(password);
	}

	@Then("^Login fails due to invalid username$")
	public void login_fails_due_to_invalid_username() throws Throwable {
		WebElement loginButton = LoginPOM.getLoginButton();
		loginButton.click();
	}

	@When("^User enters valid username \"([^\"]*)\" and invalid password \"([^\"]*)\"$")
	public void user_enters_valid_username_and_invalid_password(String username, String password) throws Throwable {
		WebElement userField = LoginPOM.getUserField();
		userField.sendKeys(username);

		WebElement passwordField = LoginPOM.getPasswordField();
		passwordField.sendKeys(password);
	}

	@Then("^Login fails due to invalid password$")
	public void login_fails_due_to_invalid_password() throws Throwable {
		WebElement loginButton = LoginPOM.getLoginButton();
		loginButton.click();
	}

	@When("^User enters invalid username \"([^\"]*)\" and invalid password \"([^\"]*)\"$")
	public void user_enters_invalid_username_and_invalid_password(String username, String password) throws Throwable {
		WebElement userField = LoginPOM.getUserField();
		userField.sendKeys(username);

		WebElement passwordField = LoginPOM.getPasswordField();
		passwordField.sendKeys(password);
	}

	@Then("^Login fails$")
	public void login_fails() throws Throwable {
		WebElement loginButton = LoginPOM.getLoginButton();
		loginButton.click();
	}
}
