package client;

import entities.Author;
import service.AuthorService;
import service.AuthorServiceImpl;

public class Client {
	public static void main(String[] args) {

		AuthorService service=new AuthorServiceImpl();
	
		Author author = new Author();
	/*	author.setAuthorId(101);
		author.setFirstName("San");
		author.setMiddleName("anvis");
		author.setLastName("Samhi");
		author.setPhoneNo(770290);
		service.addAuthor(author);*/
		
		author = service.findAuthorById(100);
		System.out.print("ID:"+author.getAuthorId());
		System.out.println(" Name:"+author.getFirstName());
		System.out.println(" Name:"+author.getMiddleName());
		System.out.println(" Name:"+author.getLastName());
		System.out.println(" PhoneNo:"+author.getPhoneNo());
		
	/*	author.setFirstName("Samanvi");
		service.updateAuthor(author);*/
		
		service.removeAuthor(author);
		
		/*author = service.findAuthorById(100);
		System.out.print("ID:"+author.getAuthorId());
		System.out.println(" Name:"+author.getFirstName());*/

	}
}
