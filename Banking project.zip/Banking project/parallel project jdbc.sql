create table BankAccount (
account_id number(10),
customer_name varchar2(20),
contact_number number(20),
amount number(15),
city varchar2(20),
state varchar2(20));

insert into BankAccount values(101,'Sanju',7995727226,1000,'kakinada','AP');
insert into BankAccount values(102,'Anu',9154220822,2000,'Rjy','AP');
insert into BankAccount values(103,'Hari',9491069209,3000,'Smlkt','AP');
insert into BankAccount values(104,'Raghu',9010634343,4000,'Vjw','AP');
insert into BankAccount values(105,'Lavanya',9632581470,5000,'Vizag','AP');

select * from BankAccount;

CREATE SEQUENCE acc_seq
start with 201
increment by 1
minvalue 200
maxvalue 500
cycle;


create table Trans_info(
Transaction_Id number(10),
Account_Id   number(10),
TransactionDate date , 
Transaction_Amount  number(20),
TransactionType varchar(25) Not Null
);

delete from trans_info where transaction_id=100;
select * from trans_info;
insert into trans_info values(100,101,'23-09-2019',7000,'WITHDRAW');

CREATE SEQUENCE trans_seq
start with 201
increment by 1
minvalue 200
maxvalue 500
cycle;
.................................................................................JPA

drop table BankCustomer;
Create table BankCustomer (

AadharNumber number(12), 
Balance number(10),
Name varchar2(20), 
PhoneNumber number(10), 
AccountNumber number(12));

insert into BankCustomer values(123456789012,20000,'Sanjana',9573888370,0123456);
insert into BankCustomer values(098745612345,30000,'Anusha',9010973158,0123457);
insert into BankCustomer values(569875421304,40000,'Lavanyaa',9908912816,0123458);
insert into BankCustomer values(965812307845,50000,'Sushma',9010696581,0123459);

select * from BankCustomer;

commit;
