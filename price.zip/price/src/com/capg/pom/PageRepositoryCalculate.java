package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

public class PageRepositoryCalculate {

	static WebDriver driver;

	public static WebDriver getDriver() {
		driver = WebUtil.getWebDriver();
		return driver;
	}

	public static WebElement getPrice() {
		return driver.findElement(By.id("price"));
	}

	public static WebElement getQuantity() {
		return driver.findElement(By.id("quantity"));
	}

	public static WebElement getButton() {
		return driver.findElement(By.id("btnSubmit"));
	}
}
