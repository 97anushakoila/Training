package com.capg.stepdefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.PageRepositoryCalculate;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefination {

	WebDriver driver;

	@Given("^Open any browser and enter URL$")
	public void open_any_browser_and_enter_URL() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		driver = PageRepositoryCalculate.getDriver();
		String url = "C:\\Users\\ganushak\\Downloads\\BDDPriceQuantity\\html\\price.html";
		driver.get(url);
	}

	@When("^User enter price \"([^\"]*)\" and quantity \"([^\"]*)\"$")
	public void user_enter_price_and_quantity(String prc, String qty) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement price = PageRepositoryCalculate.getPrice();
		price.sendKeys(prc);
		WebElement quantity = PageRepositoryCalculate.getQuantity();
		quantity.sendKeys(qty);

	}

	@Then("^calculate total$")
	public void calculate_total() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement button = PageRepositoryCalculate.getButton();
		button.click();
		// driver.switchTo().alert().accept();
		//driver.close();
	}

	@When("^User enter less price \"([^\"]*)\" and quantity \"([^\"]*)\"$")
	public void user_enter_less_price_and_quantity(String prc, String qty) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement price = PageRepositoryCalculate.getPrice();
		price.sendKeys(prc);
		WebElement quantity = PageRepositoryCalculate.getQuantity();
		quantity.sendKeys(qty);
	}

	@Then("^Dont calculate$")
	public void dont_calculate() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement button = PageRepositoryCalculate.getButton();
		button.click();
		// driver.close();
	}

}
